package com.flowable.trainosoft.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.flowable.trainosoft.pojo.CategoryJson;
import com.flowable.trainosoft.service.CategoryService;

@RestController
@RequestMapping("category-management")
public class CategoryController {
	private static final String ADD_CATEGORY_END_POINT = "/category";
	private static final String LIST_CATEGORY_END_POINT = "/categories";
	private static final String UPDATE_CATEGORY_END_POINT = "/category";

	@Autowired
	private CategoryService categoryService;

	@PostMapping(ADD_CATEGORY_END_POINT)
	public ResponseEntity<Object> addCategory(@RequestBody CategoryJson categoryJson) {
		return categoryService.addCategory(categoryJson);
	}

	@GetMapping(LIST_CATEGORY_END_POINT)
	public ResponseEntity<Object> listCategories(@RequestParam("status") Integer status) {
		return categoryService.listCategories(status);
	}

	@PutMapping(UPDATE_CATEGORY_END_POINT)
	public ResponseEntity<Object> updateCategory(@RequestBody CategoryJson categoryJson) {
		return categoryService.updateCategory(categoryJson);
	}

}
