package com.flowable.trainosoft.service;

import org.springframework.http.ResponseEntity;

import com.flowable.trainosoft.pojo.CategoryJson;
import com.flowable.trainosoft.pojo.SupplierJson;

public interface SupplierService {
	public ResponseEntity<Object> addSupplier(SupplierJson supplierJson);

	public ResponseEntity<Object> listSuppliers(Integer status);

	public ResponseEntity<Object> updateSupplier(SupplierJson supplierJson);
}
