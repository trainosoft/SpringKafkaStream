package com.flowable.trainosoft.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.flowable.trainosoft.pojo.SupplierJson;
import com.flowable.trainosoft.service.SupplierService;

@RestController
@RequestMapping("supplier-management")
public class SupplierController {
	
	private static final String ADD_SUPPLIER_END_POINT = "/supplier";
	private static final String LIST_SUPPLIER_END_POINT = "/suppliers";
	private static final String UPDATE_SUPPLIER_END_POINT = "/supplier";

	@Autowired
	private SupplierService supplierService;

	@PostMapping(ADD_SUPPLIER_END_POINT)
	public ResponseEntity<Object> addSupplier(@RequestBody SupplierJson supplierJson) {
		return supplierService.addSupplier(supplierJson);
	}

	@GetMapping(LIST_SUPPLIER_END_POINT)
	public ResponseEntity<Object> listSuppliers(@RequestParam("status") Integer status) {
		return supplierService.listSuppliers(status);
	}

	@PutMapping(UPDATE_SUPPLIER_END_POINT)
	public ResponseEntity<Object> updateSupplier(@RequestBody SupplierJson supplierJson) {
		return supplierService.updateSupplier(supplierJson);
	}

}
