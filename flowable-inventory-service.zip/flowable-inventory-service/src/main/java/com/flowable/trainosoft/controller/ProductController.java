package com.flowable.trainosoft.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.flowable.trainosoft.pojo.ProductJson;
import com.flowable.trainosoft.service.ProductService;

@RestController
@RequestMapping("product-management")
public class ProductController {
	private static final String ADD_PRODUCT_END_POINT = "/product";
	private static final String LIST_PRODUCT_END_POINT = "/products";
	private static final String UPDATE_PRODUCT_END_POINT = "/product";

	@Autowired
	private ProductService productService;

	@PostMapping(ADD_PRODUCT_END_POINT)
	public ResponseEntity<Object> addProduct(@RequestBody ProductJson productJson) {
		return productService.addProduct(productJson);
	}

	@GetMapping(LIST_PRODUCT_END_POINT)
	public ResponseEntity<Object> listProducts(@RequestParam("status") Integer status) {
		return productService.listProducts(status);
	}

	@PutMapping(UPDATE_PRODUCT_END_POINT)
	public ResponseEntity<Object> updateProducts(@RequestBody ProductJson productJson) {
		return productService.updateProduct(productJson);
	}

}
