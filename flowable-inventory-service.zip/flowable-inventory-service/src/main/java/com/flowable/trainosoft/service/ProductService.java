package com.flowable.trainosoft.service;

import org.springframework.http.ResponseEntity;

import com.flowable.trainosoft.pojo.ProductJson;

public interface ProductService {
	public ResponseEntity<Object> addProduct(ProductJson productJson);

	public ResponseEntity<Object> listProducts(Integer status);

	public ResponseEntity<Object> updateProduct(ProductJson productJson);
	
	public ResponseEntity<Object> updateProductQuantity(Long productId, Integer quantity);
}
