package com.flowable.trainosoft.kafka.listener;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.cloud.stream.messaging.Sink;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectReader;
import com.flowable.trainosoft.entity.Product;
import com.flowable.trainosoft.kafka.sender.Message;
import com.flowable.trainosoft.kafka.sender.MessageSender;
import com.flowable.trainosoft.pojo.ItemJson;
import com.flowable.trainosoft.pojo.OrderJson;
import com.flowable.trainosoft.repository.ProductRepository;

@Component
@EnableBinding(Sink.class)
public class MessageListener {

	private static final Logger LOGGER = LoggerFactory.getLogger(MessageListener.class);
	private static final String EVENT_INVENTORY_STATUS = "inventory-status-event";

	@Autowired
	private MessageSender messageSender;

	@Autowired
	private ObjectMapper objectMapper;

	@Autowired
	private ProductRepository productRepository;

	@StreamListener(target = Sink.INPUT, condition = "(headers['type']?:'')=='order-inventory-check-event'")
	public void checkInventoryEvent(String messageJson) throws IOException {
		LOGGER.info("checkInventoryEvent received : {}", messageJson);

		JsonNode message = objectMapper.readTree(messageJson);
		String eventType = message.get("type") == null ? "" : message.get("type").asText();
		LOGGER.info("eventType : {}", eventType);
		JsonNode orderNodeJson = message.get("data");

		LOGGER.info("order id : {}", orderNodeJson.get("orderId"));
		LOGGER.info("totalAmount : {}", orderNodeJson.get("totalAmount"));

		Long orderId = orderNodeJson.get("orderId").asLong();
		Double totalAmount = orderNodeJson.get("totalAmount").asDouble();
		JsonNode itemsNode = orderNodeJson.get("items");
		ObjectReader reader = objectMapper.readerFor(new TypeReference<List<ItemJson>>() {
		});

		String processInstanceId = orderNodeJson.get("processInstanceId").asText();

		List<ItemJson> itemJsons = reader.readValue(itemsNode);
		LOGGER.info("itemJsons size : {}", itemJsons.size());

		// Checking items in the inventory
		Boolean isAllItemAvailableInStock = true;
		for (ItemJson itemJson : itemJsons) {
			LOGGER.info("order id : {}", orderId);
			Optional<Product> productData = productRepository.findById(itemJson.getItemId());
			if (productData.isEmpty()) {
				Integer totalItemAvailable = productData.get().getQuantity();
				LOGGER.info("totalItemAvailable : {}", totalItemAvailable);
				if (totalItemAvailable == 0) {
					isAllItemAvailableInStock = false;
				}
			}
		}

		OrderJson orderJson = new OrderJson();
		orderJson.setIsAllItemAvailableInStock(isAllItemAvailableInStock);
		orderJson.setOrderId(orderId);
		orderJson.setTotalAmount(totalAmount);
		orderJson.setItems(itemJsons);
		orderJson.setProcessInstanceId(processInstanceId);
		
		LOGGER.info("final totalItemAvailable : {}", isAllItemAvailableInStock);

		Message<OrderJson> inventoryStatusMessage = new Message<OrderJson>(EVENT_INVENTORY_STATUS, orderJson);
		messageSender.send(inventoryStatusMessage);

	}

	/*
	 * @StreamListener(target = Sink.INPUT, condition =
	 * "(headers['type']?:'')=='payment-received-event'")
	 * 
	 * @Transactional public void receivedPayment(String messageJson) throws
	 * JsonMappingException, JsonProcessingException {
	 * LOGGER.info("payment-received-event received : {}", messageJson);
	 * 
	 * JsonNode message = objectMapper.readTree(messageJson); String eventType =
	 * message.get("type").asText(); LOGGER.info("eventType : {}", eventType);
	 * 
	 * ObjectNode payload = (ObjectNode) message.get("data");
	 * 
	 * String orderId = payload.get("refId").asText();
	 * 
	 * LOGGER.info("orderId : {}", orderId);
	 * 
	 * if (orderId == null) { orderId = UUID.randomUUID().toString();
	 * payload.put("orderId", orderId); }
	 * 
	 * // and kick of a fetching goods flow List<MessageCorrelationResult>
	 * correlationResults =
	 * processEngine.getRuntimeService().createMessageCorrelation(eventType).
	 * processInstanceVariableEquals("orderId", orderId) .correlateAllWithResult();
	 * LOGGER.info("correlationResults size : {}", correlationResults.size());
	 * 
	 * }
	 * 
	 * @StreamListener(target = Sink.INPUT, condition =
	 * "(headers['type']?:'')=='good-fetched-event'")
	 * 
	 * @Transactional public void fetchedGoods(String messageJson) throws
	 * JsonMappingException, JsonProcessingException {
	 * LOGGER.info("good-fetched-event received : {}", messageJson);
	 * 
	 * JsonNode message = objectMapper.readTree(messageJson); String eventType =
	 * message.get("type").asText(); LOGGER.info("eventType : {}", eventType);
	 * 
	 * String orderId = message.get("traceid").toString();
	 * 
	 * LOGGER.info("orderId : {}", orderId);
	 * 
	 * List<MessageCorrelationResult> correlationResults =
	 * processEngine.getRuntimeService().createMessageCorrelation(eventType)
	 * .correlateAllWithResult(); LOGGER.info("correlationResults size : {}",
	 * correlationResults.size());
	 * 
	 * }
	 */

}
