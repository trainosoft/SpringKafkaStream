package com.flowable.trainosoft.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flowable.trainosoft.entity.Supplier;
import com.flowable.trainosoft.pojo.SupplierJson;
import com.flowable.trainosoft.repository.SupplierRepository;
import com.flowable.trainosoft.service.SupplierService;

@Service
public class SupplierServiceImpl implements SupplierService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private SupplierRepository supplierRepository;

	@Override
	public ResponseEntity<Object> addSupplier(SupplierJson supplierJson) {
		logger.debug("Adding new Supplier");

		try {
			Supplier supplier = new Supplier();
			supplier.setName(supplierJson.getName());
			supplier.setDescription(supplierJson.getDescription());
			supplier.setStatus(supplierJson.getStatus());

			supplier = supplierRepository.saveAndFlush(supplier);

			logger.debug("New Supplier creating : {}", supplier.toString());

			return ResponseEntity.status(HttpStatus.CREATED).body(supplier);
		} catch (Exception e) {
			logger.error("Exception occired while creating new product Supplier : ", e);
			return new ResponseEntity<>("Supplier could not be created", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<Object> listSuppliers(Integer status) {
		logger.debug("Retrieving suppliers by status : {}", status);

		try {
			List<Supplier> suppliers = supplierRepository.findByStatus(status);
			return ResponseEntity.ok().body(suppliers);
		} catch (Exception e) {
			logger.error("Exception occired while retrieving product suppliers : ", e);
			return new ResponseEntity<>("Suppliers could not be retrieved", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<Object> updateSupplier(SupplierJson supplierJson) {
		logger.debug("Updating Supplier for id : {}", supplierJson.getId());

		try {
			Optional<Supplier> supplierData = supplierRepository.findById(supplierJson.getId());
			if (!supplierData.isPresent()) {
				return new ResponseEntity<>("Supplier does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			Supplier supplier = supplierData.get();
			supplier.setName(supplierJson.getName());
			supplier.setDescription(supplierJson.getDescription());

			supplierRepository.saveAndFlush(supplier);

			return ResponseEntity.ok().body("Supplier updated successfully");
		} catch (Exception e) {
			logger.error("Exception occired while updating product suppliers : ", e);
			return new ResponseEntity<>("Supplier could not be updated", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
