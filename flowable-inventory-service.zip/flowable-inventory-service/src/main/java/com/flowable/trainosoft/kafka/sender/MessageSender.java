package com.flowable.trainosoft.kafka.sender;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.EnableBinding;
import org.springframework.cloud.stream.messaging.Source;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
@EnableBinding(Source.class)
public class MessageSender {
	@Autowired
	private MessageChannel output;

	@Autowired
	private ObjectMapper objectMapper;

	public void send(Message<?> m) {
		
		try {
			String messageJson = objectMapper.writeValueAsString(m);
			output.send(MessageBuilder.withPayload(messageJson).setHeader("type", m.getType()).build());
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}

