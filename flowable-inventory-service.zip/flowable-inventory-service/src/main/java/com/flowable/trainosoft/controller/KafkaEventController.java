package com.flowable.trainosoft.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flowable.trainosoft.kafka.sender.Message;
import com.flowable.trainosoft.kafka.sender.MessageSender;
import com.flowable.trainosoft.pojo.Payment;

@RestController
public class KafkaEventController {
	@Autowired
	private MessageSender messageSender;

	@GetMapping("/send")
	public ResponseEntity<Object> send() {

		Payment payment = new Payment();
		payment.setCustId("001");
		payment.setBankName("HDFC");
		payment.setBankAccount("1232iy34");
		payment.setPaymentAmount(50000.0);

		Message<Payment> message = new Message<Payment>();
		message.setData(payment);
		messageSender.send(message);

		return ResponseEntity.ok().body("Event sent successfully");
	}
}
