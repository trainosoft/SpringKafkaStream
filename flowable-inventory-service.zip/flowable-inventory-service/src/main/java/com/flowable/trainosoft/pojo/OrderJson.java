package com.flowable.trainosoft.pojo;

import java.util.List;

public class OrderJson {

	private Long orderId;
	private Double totalAmount;
	private List<ItemJson> items;
	private Boolean isAllItemAvailableInStock;
	private String processInstanceId;

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public List<ItemJson> getItems() {
		return items;
	}

	public void setItems(List<ItemJson> items) {
		this.items = items;
	}

	public Boolean getIsAllItemAvailableInStock() {
		return isAllItemAvailableInStock;
	}

	public void setIsAllItemAvailableInStock(Boolean isAllItemAvailableInStock) {
		this.isAllItemAvailableInStock = isAllItemAvailableInStock;
	}

	public String getProcessInstanceId() {
		return processInstanceId;
	}

	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}

}
