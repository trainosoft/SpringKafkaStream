package com.flowable.trainosoft.service.impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flowable.trainosoft.entity.Category;
import com.flowable.trainosoft.pojo.CategoryJson;
import com.flowable.trainosoft.repository.CategoryRepository;
import com.flowable.trainosoft.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	public ResponseEntity<Object> addCategory(CategoryJson categoryJson) {
		logger.debug("Adding new category");

		try {
			Category category = new Category();
			category.setName(categoryJson.getName());
			category.setDescription(categoryJson.getDescription());
			category.setStatus(categoryJson.getStatus());

			category = categoryRepository.saveAndFlush(category);

			logger.debug("New category creating : {}", category.toString());

			return ResponseEntity.status(HttpStatus.CREATED).body(category);
		} catch (Exception e) {
			logger.error("Exception occired while creating new product category : ", e);
			return new ResponseEntity<>("Category could not be created", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<Object> listCategories(Integer status) {
		logger.debug("Retrieving categories by status : {}", status);

		try {
			List<Category> categories = categoryRepository.findByStatus(status);
			return ResponseEntity.ok().body(categories);
		} catch (Exception e) {
			logger.error("Exception occired while retrieving product categories : ", e);
			return new ResponseEntity<>("Categories could not be retrieved", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<Object> updateCategory(CategoryJson categoryJson) {
		logger.debug("Updating category for id : {}", categoryJson.getId());

		try {
			Optional<Category> categoryData = categoryRepository.findById(categoryJson.getId());
			if (!categoryData.isPresent()) {
				return new ResponseEntity<>("Category does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			categoryRepository.saveAndFlush(categoryData.get());
			return ResponseEntity.ok().body("Category updated successfully");
		} catch (Exception e) {
			logger.error("Exception occired while retrieving product categories : ", e);
			return new ResponseEntity<>("Categories could not be retrieved", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
