package com.flowable.trainosoft.service.impl;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.flowable.trainosoft.entity.Category;
import com.flowable.trainosoft.entity.Product;
import com.flowable.trainosoft.entity.Supplier;
import com.flowable.trainosoft.pojo.ProductJson;
import com.flowable.trainosoft.repository.CategoryRepository;
import com.flowable.trainosoft.repository.ProductRepository;
import com.flowable.trainosoft.repository.SupplierRepository;
import com.flowable.trainosoft.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CategoryRepository categoryRepository;

	@Autowired
	private SupplierRepository supplierRepository;

	@Autowired
	private ProductRepository productRepository;

	@Override
	public ResponseEntity<Object> addProduct(ProductJson productJson) {
		logger.debug("Adding new Supplier");

		try {

			Optional<Category> categoryData = categoryRepository.findById(productJson.getCategory().getId());
			if (!categoryData.isPresent()) {
				return new ResponseEntity<>("Category does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			Optional<Supplier> supplierData = supplierRepository.findById(productJson.getSupplier().getId());
			if (!supplierData.isPresent()) {
				return new ResponseEntity<>("Supplier does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			Category category = categoryData.get();
			Supplier supplier = supplierData.get();

			Product product = new Product();
			product.setName(productJson.getName());
			product.setDescription(productJson.getDescription());
			product.setPrice(productJson.getPrice());
			product.setQuantity(productJson.getQuantity());
			product.setCategory(category);
			product.setSupplier(supplier);
			product.setStatus(productJson.getStatus());

			product = productRepository.saveAndFlush(product);

			return ResponseEntity.status(HttpStatus.CREATED).body(product);
		} catch (Exception e) {
			logger.error("Exception occired while creating new product Supplier : ", e);
			return new ResponseEntity<>("Supplier could not be created", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	public ResponseEntity<Object> listProducts(Integer status) {
		logger.debug("Retrieving suppliers by status : {}", status);

		try {
			List<Product> products = productRepository.findByStatus(status);
			return ResponseEntity.ok().body(products);
		} catch (Exception e) {
			logger.error("Exception occired while retrieving products : ", e);
			return new ResponseEntity<>("Products could not be retrieved", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Transactional
	public ResponseEntity<Object> updateProduct(ProductJson productJson) {
		logger.debug("Updating Supplier for id : {}", productJson.getId());

		try {

			Optional<Product> productData = productRepository.findById(productJson.getId());
			if (!productData.isPresent()) {
				return new ResponseEntity<>("Product does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			Optional<Category> categoryData = categoryRepository.findById(productJson.getCategory().getId());
			if (!categoryData.isPresent()) {
				return new ResponseEntity<>("Category does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			Optional<Supplier> supplierData = supplierRepository.findById(productJson.getSupplier().getId());
			if (!supplierData.isPresent()) {
				return new ResponseEntity<>("Supplier does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
			}

			Product product = productData.get();
			product.setCategory(categoryData.get());
			product.setSupplier(supplierData.get());
			product.setName(productJson.getName());
			product.setDescription(productJson.getDescription());
			product.setQuantity(productJson.getQuantity());
			product.setStatus(productJson.getStatus());

			productRepository.save(product);

			return ResponseEntity.ok().body("Supplier updated successfully");
		} catch (Exception e) {
			logger.error("Exception occired while updating product supplier : ", e);
			return new ResponseEntity<>("Supplier could not be updated", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@Override
	@Transactional
	public ResponseEntity<Object> updateProductQuantity(Long productId, Integer quantity) {
		Optional<Product> productData = productRepository.findById(productId);
		if (!productData.isPresent()) {
			return new ResponseEntity<>("Product does not exist ", HttpStatus.UNPROCESSABLE_ENTITY);
		}

		try {
			Product product = productData.get();
			Integer updatedQuantity = product.getQuantity() - 1;
			product.setQuantity(updatedQuantity);
			return ResponseEntity.ok().body("Product quantity updated successfully");
		} catch (Exception e) {
			logger.error("Exception occired while updating product quantity : ", e);
			return new ResponseEntity<>("Product quantity could not be updated", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

}
