package com.flowable.trainosoft.service;

import org.springframework.http.ResponseEntity;

import com.flowable.trainosoft.pojo.CategoryJson;

public interface CategoryService {
	public ResponseEntity<Object> addCategory(CategoryJson categoryJson);
	public ResponseEntity<Object> listCategories(Integer status);
	public ResponseEntity<Object> updateCategory(CategoryJson categoryJson);

}
